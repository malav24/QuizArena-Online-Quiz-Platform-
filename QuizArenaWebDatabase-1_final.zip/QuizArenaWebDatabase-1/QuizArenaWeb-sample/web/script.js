/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

const quiz = document.getElementById('quiz');
const answerEls = document.querySelectorAll('.answer');
const questionEl = document.getElementById('question');
const a_text = document.getElementById('a_text');
const b_text = document.getElementById('b_text');
const c_text = document.getElementById('c_text');
const d_text = document.getElementById('d_text');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const questionList = document.getElementById('questionList');

let currentQuiz = 0;
let answers = new Array(quizData.length).fill(null);
let timeLeft = 10 * 60; // 10 minutes in seconds
let timerInterval;

function startTimer() {
    timerInterval = setInterval(() => {
        timeLeft--;
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        document.getElementById('time').textContent = 
            `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        
        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            alert('Time is up!');
            // You can add additional logic here for when time runs out
        }
    }, 1000);
}

function loadQuiz() {
    deselectAnswers();

    const currentQuizData = quizData[currentQuiz];

    questionEl.innerText = currentQuizData.question;
    a_text.innerText = currentQuizData.a;
    b_text.innerText = currentQuizData.b;
    c_text.innerText = currentQuizData.c;
    d_text.innerText = currentQuizData.d;

    if (answers[currentQuiz] !== null) {
        document.getElementById(answers[currentQuiz]).checked = true;
    }

    updateQuestionList();
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false);
}

function getSelected() {
    let answer = null;
    answerEls.forEach(answerEl => {
        if (answerEl.checked) {
            answer = answerEl.id.toLowerCase();
            console.log("Selected answer:", answer);
        }
    });
    return answer;
}

function updateQuestionList() {
    questionList.innerHTML = "";
    quizData.forEach((_, index) => {
        const listItem = document.createElement("li");
        listItem.innerText = index + 1;
        listItem.classList.add(answers[index] ? "answered" : "unanswered");
        listItem.addEventListener("click", () => {
            currentQuiz = index;
            loadQuiz();
            updateButtons();
        });
        questionList.appendChild(listItem);
    });
}

nextBtn.addEventListener("click", () => {
    const answer = getSelected();
    if (answer) {
        answers[currentQuiz] = answer;
        console.log(`Stored answer for question ${currentQuiz + 1}:`, answer);
    }

    if (currentQuiz < quizData.length - 1) {
        currentQuiz++;
        loadQuiz();
        updateButtons();
    } else {
        // Last question, so finish the quiz
        finishQuiz();
    }
});

prevBtn.addEventListener("click", () => {
    if (currentQuiz > 0) {
        currentQuiz--;
        loadQuiz();
    }

    updateButtons();
});

function updateButtons() {
    prevBtn.disabled = currentQuiz === 0;
    nextBtn.innerText = currentQuiz === quizData.length - 1 ? "Finish" : "Next";
}

// Start the timer when the page loads
startTimer();

loadQuiz();
updateButtons();

// Add debug logging for quiz data when page loads
console.log("Quiz Data:", quizData);

function finishQuiz() {
    // Calculate score
    let score = 0;
    let totalQuestions = quizData.length;
    console.log("Starting score calculation...");
    console.log("Total questions:", totalQuestions);
    console.log("Quiz Data:", JSON.stringify(quizData, null, 2));
    console.log("All answers:", answers);
    
    // Calculate score
    for(let i = 0; i < quizData.length; i++) {
        const selectedAnswer = answers[i];
        const currentQuestion = quizData[i];
        
        console.log(`\nQuestion ${i + 1}:`);
        console.log(`Question text: ${currentQuestion.question}`);
        console.log(`Selected option letter: ${selectedAnswer}`);
        console.log(`Correct option letter: ${currentQuestion.correct}`);
        
        // Compare the selected answer letter with the correct answer letter
        if (selectedAnswer && currentQuestion.correct && 
            selectedAnswer.toLowerCase() === currentQuestion.correct.toLowerCase()) {
            console.log("Correct!");
            score++;
        } else {
            console.log("Incorrect or not answered");
            console.log("Selected letter:", selectedAnswer);
            console.log("Correct letter:", currentQuestion.correct);
        }
    }
    
    console.log(`\nFinal score: ${score} out of ${totalQuestions}`);

    // Submit via form
    const form = document.createElement('form');
    const quizId = new URLSearchParams(window.location.search).get('quizId');
    console.log("Quiz ID:", quizId);
    
    form.action = 'QuizResultServlet';
    form.method = 'POST';
    form.innerHTML += `<input type="hidden" name="quizId" value="${quizId}">`;
    form.innerHTML += `<input type="hidden" name="score" value="${score}">`;
    document.body.appendChild(form);
    form.submit();
}