package database;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class ConnectServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();

        String host = "localhost";
        String user = "root";
        String password = request.getParameter("password");
        String dbName = "quizweb";

        Connection conn = null;
        Statement stmt = null;

        try {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Step 1: Connect to MySQL (without DB)
            conn = DriverManager.getConnection("jdbc:mysql://" + host + ":3306/?useSSL=false&allowPublicKeyRetrieval=true", user, password);
            stmt = conn.createStatement();

            // Step 2: Create the database
            stmt.executeUpdate("CREATE DATABASE IF NOT EXISTS " + dbName);

            // Step 3: Connect to the created database
            conn = DriverManager.getConnection("jdbc:mysql://" + host + ":3306/" + dbName + "?useSSL=false&allowPublicKeyRetrieval=true", user, password);
            stmt = conn.createStatement();

            // Step 4: Create tables
            stmt.executeUpdate(
                "CREATE TABLE IF NOT EXISTS User (" +
                "UserID INT AUTO_INCREMENT PRIMARY KEY," +
                "UserName VARCHAR(50)," +
                "Password VARCHAR(100)," +
                "Email VARCHAR(100)," +
                "Role VARCHAR(20)," +
                "DOB DATE" +
                ");"
            );

            stmt.executeUpdate(
                "CREATE TABLE IF NOT EXISTS Student (" +
                "StudentID INT AUTO_INCREMENT PRIMARY KEY," +
                "Name VARCHAR(100)," +
                "UserID INT," +
                "Grade VARCHAR(10)," +
                "FOREIGN KEY (UserID) REFERENCES User(UserID)" +
                ");"
            );

            stmt.executeUpdate(
                "CREATE TABLE IF NOT EXISTS Teacher (" +
                "TeacherID INT AUTO_INCREMENT PRIMARY KEY," +
                "Name VARCHAR(100)," +
                "UserID INT," +
                "SubjectSpecialization VARCHAR(100)," +
                "FOREIGN KEY (UserID) REFERENCES User(UserID)" +
                ");"
            );

            stmt.executeUpdate(
                "CREATE TABLE IF NOT EXISTS Domain (" +
                "DomainID INT AUTO_INCREMENT PRIMARY KEY," +
                "DomainName VARCHAR(100)," +
                "QuizCount INT" +
                ");"
            );

            stmt.executeUpdate(
                "CREATE TABLE IF NOT EXISTS Quiz (" +
                "QuizID INT AUTO_INCREMENT PRIMARY KEY," +
                "Title VARCHAR(100)," +
                "DomainID INT," +
                "TeacherID INT," +
                "FOREIGN KEY (DomainID) REFERENCES Domain(DomainID)," +
                "FOREIGN KEY (TeacherID) REFERENCES Teacher(TeacherID)" +
                ");"
            );

            stmt.executeUpdate(
                "CREATE TABLE IF NOT EXISTS Question (" +
                "QuestionID INT AUTO_INCREMENT PRIMARY KEY," +
                "QuizID INT," +
                "QuestionText TEXT," +
                "Option1 VARCHAR(255)," +
                "Option2 VARCHAR(255)," +
                "Option3 VARCHAR(255)," +
                "Option4 VARCHAR(255)," +
                "CorrectOption VARCHAR(255)," +
                "FOREIGN KEY (QuizID) REFERENCES Quiz(QuizID)" +
                ");"
            );

            stmt.executeUpdate(
                "CREATE TABLE IF NOT EXISTS Result (" +
                "AttemptID INT AUTO_INCREMENT PRIMARY KEY," +
                "StudentID INT," +
                "QuizID INT," +
                "Score INT," +
                "AttemptDate DATETIME," +
                "FOREIGN KEY (StudentID) REFERENCES Student(StudentID)," +
                "FOREIGN KEY (QuizID) REFERENCES Quiz(QuizID)" +
                ");"
            );

            stmt.executeUpdate(
                "CREATE TABLE IF NOT EXISTS LoginHistory (" +
                "LoginID INT AUTO_INCREMENT PRIMARY KEY," +
                "UserID INT," +
                "LoginTime DATETIME," +
                "LogoutTime DATETIME," +
                "FOREIGN KEY (UserID) REFERENCES User(UserID)" +
                ");"
            );

            // Step 5: Clear existing data (truncate tables in reverse order of dependencies)
            stmt.executeUpdate("SET FOREIGN_KEY_CHECKS = 0;");
            stmt.executeUpdate("TRUNCATE TABLE Result;");
            stmt.executeUpdate("TRUNCATE TABLE Question;");
            stmt.executeUpdate("TRUNCATE TABLE Quiz;");
            stmt.executeUpdate("TRUNCATE TABLE Domain;");
            stmt.executeUpdate("TRUNCATE TABLE Teacher;");
            stmt.executeUpdate("TRUNCATE TABLE Student;");
            stmt.executeUpdate("TRUNCATE TABLE LoginHistory;");
            stmt.executeUpdate("TRUNCATE TABLE User;");
            stmt.executeUpdate("SET FOREIGN_KEY_CHECKS = 1;");

            // Step 6: Insert sample data
            // User table
            stmt.executeUpdate(
                "INSERT INTO User (UserID, UserName, Password, Email, Role, DOB) VALUES " +
                "(1, 'Preet', 'Preet@001', 'Preet001@email.com', 'Teacher', '1980-03-12')," +
                "(2, 'Meet', 'Meet@002', 'Meet002@email.com', 'Student', '2005-07-25')," +
                "(3, 'Farhan', 'Farhan@003', 'Farhan003@email.com', 'Teacher', '1981-11-08')," +
                "(4, 'Harsh', 'Harsh@004', 'Harsh004@email.com', 'Teacher', '1975-05-15')," +
                "(5, 'Malav', 'Malav@005', 'Malav005@email.com', 'Student', '2005-09-30')," +
                "(6, 'Dhruv', 'Dhruv@006', 'Dhruv006@email.com', 'Student', '2005-02-18')," +
                "(7, 'Hem', 'Hem@007', 'Hem007@email.com', 'Student', '2006-06-22')," +
                "(8, 'Shubham', 'Shubham@008', 'Shubham008@email.com', 'Student', '2004-12-10')," +
                "(9, 'Harsh', 'Harsh@009', 'Harsh009@email.com', 'Student', '2005-08-27')," +
                "(10, 'Rishi', 'Rishi@010', 'Rishi010@email.com', 'Student', '2006-04-05')," +
                "(11, 'Heer', 'Heer@011', 'Heer011@email.com', 'Teacher', '1980-10-14')," +
                "(12, 'Diti', 'Diti@012', 'Diti012@email.com', 'Student', '2006-01-07')," +
                "(13, 'Shreya', 'Shreya@013', 'Shreya013@email.com', 'Teacher', '1970-07-19')," +
                "(14, 'Hardi', 'Hardi@014', 'Hardi014@email.com', 'Student', '2005-05-02')," +
                "(15, 'Hardi', 'Hardi@015', 'Hardi015@email.com', 'Student', '2002-09-09');"
            );

            // Student table
            stmt.executeUpdate(
                "INSERT INTO Student (StudentID, Name, UserID, Grade) VALUES " +
                "(32001, 'Meet', 2, 'A')," +
                "(32002, 'Malav', 5, 'B+')," +
                "(32003, 'Dhruv', 6, 'A-')," +
                "(32004, 'Hem', 7, 'B')," +
                "(32005, 'Shubham', 8, 'A+')," +
                "(32006, 'Harsh', 9, 'B+')," +
                "(32007, 'Rishi', 10, 'A')," +
                "(32008, 'Diti', 12, 'A')," +
                "(32009, 'Hardi', 14, 'B+')," +
                "(32010, 'Hardi', 15, 'B');"
            );

            // Teacher table
            stmt.executeUpdate(
                "INSERT INTO Teacher (TeacherID, Name, UserID, SubjectSpecialization) VALUES " +
                "(10001, 'Preet', 1, 'JAVA')," +
                "(10002, 'Farhan', 3, 'DBMS')," +
                "(10003, 'Harsh', 4, 'DAA')," +
                "(10004, 'Heer', 11, 'JAVA LAB')," +
                "(10005, 'Shreya', 13, 'COA');"
            );

            // Domain table
            stmt.executeUpdate(
                "INSERT INTO Domain (DomainID, DomainName, QuizCount) VALUES " +
                "(1, 'JAVA', 1)," +
                "(2, 'DBMS', 1)," +
                "(3, 'DAA', 0)," +
                "(4, 'JAVA LAB', 0)," +
                "(5, 'COA', 0)," +
                "(6, 'SOCIAL SCIENCE', 0)," +
                "(7, 'CN', 0);"
            );

            // Quiz table
            stmt.executeUpdate(
                "INSERT INTO Quiz (QuizID, Title, DomainID, TeacherID) VALUES " +
                "(1, 'Core Java Fundamentals Quiz', 1, 10001)," +
                "(2, 'Database Management Essentials Quiz', 2, 10002)," +
                "(3, 'Java Intermediate', 3, 10003)," +
                "(4, 'Algorithms', 4, 10001)," +
                "(5, 'SQL Intermediate', 5, 10002)," +
                "(6, 'Communication', 6, 10005)," +
                "(7, 'COA basics', 7, 10002)," +
                "(8, 'Networking', 7, 10003);"
            );

            // Question table
            stmt.executeUpdate(
                "INSERT INTO Question (QuestionID, QuizID, QuestionText, Option1, Option2, Option3, Option4, CorrectOption) VALUES " +
                "(1, 1, 'How do you find the length of a string named ''example''?', 'example.size()', 'example.length()', 'example.getLength()', 'example.length', 'example.length()')," +
                "(2, 1, 'Which of the following data types can store a floating-point number?', 'int', 'byte', 'double', 'char', 'double')," +
                "(3, 1, 'What''s the main difference between int and Integer in Java?', 'No difference', 'Integer can store larger values than int', 'int is a primitive data type, while Integer is a class', 'int can be null, while Integer cannot', 'int is a primitive data type, while Integer is a class')," +
                "(4, 1, 'What will be the error in the following Java code? byte b = 50; b = b * 50;', 'b cannot contain value 50', 'b cannot contain value 100, limited by its range', 'No error in this code', '* operator has converted b * 50 into int, which can not be converted to byte without casting', '* operator has converted b * 50 into int, which can not be converted to byte without casting')," +
                "(5, 1, 'Which of the following is not an OOPS concept in Java?', 'Compilation', 'Polymorphism', 'Inheritance', 'Encapsulation', 'Compilation')," +
                "(6, 1, 'Which function is used to print something in Java?', 'system.out.print()', 'printf()', 'echo()', 'System.out.println()', 'System.out.println()')," +
                "(7, 1, 'Which of the following is used to take input from the user in Java?', 'system.out.print()', 'Scanner', 'InputStream', 'Console', 'Scanner')," +
                "(8, 1, 'What will be the output of System.out.println(5/2); in Java?', '2.5', '2', '2.0', 'Error', '2')," +
                "(9, 1, 'Which of the following is true about constructors in Java?', 'A constructor must have the same', 'A constructor can have any return type', 'A constructor is called manually', 'A class cannot have more than one constructor', 'A constructor must have the same name as the class')," +
                "(10, 1, 'Which of the following is a valid keyword in Java?', 'interface', 'string', 'Float', 'unsigned', 'interface')," +
                "(11, 2, 'Which of the following is an example of a DBMS?', 'MySQL', 'Microsoft Excel', 'Notepad', 'Google Chrome', 'MySQL')," +
                "(12, 2, 'Which key uniquely identifies each record in a table?', 'Primary Key', 'Foreign Key', 'Candidate Key', 'Composite Key', 'Primary Key')," +
                "(13, 2, 'Which SQL clause is used to filter records?', 'ORDER BY', 'WHERE', 'GROUP BY', 'JOIN', 'WHERE')," +
                "(14, 2, 'Which command is used to remove all records from a table but keep its structure?', 'DELETE', 'DROP', 'TRUNCATE', 'REMOVE', 'TRUNCATE')," +
                "(15, 2, 'Which key is used to establish a relationship between two tables?', 'Primary key', 'Foreign Key', 'Super Key', 'Candidate Key', 'Foreign Key')," +
                "(16, 2, 'What does SQL stand for?', 'Structured Query Language', 'Sequential Query Language', 'Standard Query Language', 'System Query Language', 'Structured Query Language')," +
                "(17, 2, 'Which command is used to remove a table permanently?', 'CLEAR', 'DELETE', 'DROP', 'ERASE', 'DROP')," +
                "(18, 2, 'Which of the following is NOT a type of join in SQL?', 'INNER JOIN', 'OUTER JOIN', 'FULL JOIN', 'UPPER JOIN', 'UPPER JOIN')," +
                "(19, 2, 'Which SQL statement is used to retrieve data from a database?', 'GET', 'SELECT', 'READ', 'FETCH', 'SELECT')," +
                "(20, 2, 'What is a tuple in a relational database?', 'A column in a table', 'A row in a table', 'A database schema', 'A stored procedure', 'A row in a table');"
            );

            // Result table
            stmt.executeUpdate(
                "INSERT INTO Result (AttemptID, StudentID, QuizID, Score, AttemptDate) VALUES " +
                "(1, 32001, 1, 7, '2025-03-28 09:23:15')," +
                "(2, 32002, 1, 5, '2025-03-03 14:45:37')," +
                "(3, 32004, 1, 5, '2025-03-05 08:12:59')," +
                "(4, 32005, 1, 6, '2025-03-07 14:45:37')," +
                "(5, 32006, 1, 4, '2025-03-10 11:58:44')," +
                "(6, 32001, 1, 9, '2025-03-12 20:07:10')," +
                "(7, 32002, 2, 5, '2025-03-15 06:35:50')," +
                "(8, 32003, 2, 8, '2025-03-18 13:48:32')," +
                "(9, 32001, 2, 10, '2025-03-20 18:20:03')," +
                "(10, 32007, 2, 3, '2025-03-22 07:55:26');"
            );

            // LoginHistory table
            stmt.executeUpdate(
                "INSERT INTO LoginHistory (LoginID, UserID, LoginTime, LogoutTime) VALUES " +
                "(1, 1, '2025-05-07 16:00:00', NULL)," +
                "(2, 2, '2025-05-07 16:15:00', NULL)," +
                "(3, 3, '2025-05-07 16:30:00', NULL)," +
                "(4, 4, '2025-05-07 16:45:00', NULL)," +
                "(5, 5, '2025-05-07 17:00:00', NULL)," +
                "(6, 6, '2025-05-07 17:15:00', NULL)," +
                "(7, 7, '2025-05-07 17:30:00', NULL)," +
                "(8, 8, '2025-05-07 17:45:00', NULL)," +
                "(9, 9, '2025-05-07 18:00:00', NULL)," +
                "(10, 10, '2025-05-07 18:15:00', NULL)," +
                "(11, 11, '2025-05-07 18:30:00', NULL)," +
                "(12, 12, '2025-05-07 18:45:00', NULL)," +
                "(13, 13, '2025-05-07 19:00:00', NULL)," +
                "(14, 14, '2025-05-07 19:15:00', NULL)," +
                "(15, 15, '2025-05-07 19:30:00', NULL);"
            );

            out.print("success");

        } catch (Exception e) {
            e.printStackTrace();
            out.print("fail: " + e.getMessage());
        } finally {
            try { if (stmt != null) stmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }
}