package main;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class QuizTestServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String quizId = request.getParameter("quizId");
        if (quizId == null || quizId.trim().isEmpty()) {
            request.setAttribute("error", "Quiz ID is required");
            request.getRequestDispatcher("Quiz-test.jsp").forward(request, response);
            return;
        }
        
        String host = "localhost";
        String user = "root";
        String password = "dd@488124";
        String dbName = "quizweb";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://" + host + ":3306/" + dbName + "?useSSL=false&allowPublicKeyRetrieval=true", user, password);
            
            // Query to get quiz questions
            String query = "SELECT QuestionID, QuestionText, Option1, Option2, Option3, Option4, CorrectOption " +
                          "FROM Question " +
                          "WHERE QuizID = ? " +
                          "ORDER BY QuestionID";
            
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, quizId);
            
            rs = pstmt.executeQuery();
            
            List<Question> questions = new ArrayList<>();
            
            while (rs.next()) {
                Question question = new Question();
                question.setId(rs.getInt("QuestionID"));
                question.setText(rs.getString("QuestionText"));
                question.setOption1(rs.getString("Option1"));
                question.setOption2(rs.getString("Option2"));
                question.setOption3(rs.getString("Option3"));
                question.setOption4(rs.getString("Option4"));
                
                // Use the correct answer text directly from the DB
                String correctOptionText = rs.getString("CorrectOption");
                String correctOptionLetter = null;

                if (correctOptionText != null) {
                    correctOptionText = correctOptionText.trim();
                    if (correctOptionText.equals(rs.getString("Option1"))) {
                        correctOptionLetter = "a";
                    } else if (correctOptionText.equals(rs.getString("Option2"))) {
                        correctOptionLetter = "b";
                    } else if (correctOptionText.equals(rs.getString("Option3"))) {
                        correctOptionLetter = "c";
                    } else if (correctOptionText.equals(rs.getString("Option4"))) {
                        correctOptionLetter = "d";
                    }
                }
                question.setCorrectOption(correctOptionLetter);
                System.out.println("CorrectOption from DB: " + correctOptionText + " | Letter: " + correctOptionLetter);
                
                questions.add(question);
            }
            
            request.setAttribute("questions", questions);
            request.getRequestDispatcher("Quiz-test.jsp").forward(request, response);
            
        } catch (Exception e) {
            request.setAttribute("error", e.getMessage());
            request.getRequestDispatcher("Quiz-test.jsp").forward(request, response);
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }
} 