package main;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class QuizServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        String domainId = request.getParameter("domainId");
        
        if (domainId == null || domainId.trim().isEmpty()) {
            out.print("{\"error\":\"Domain ID is required\"}");
            return;
        }
        
        String host = "localhost";
        String user = "root";
        String password = "dd@488124";
        String dbName = "quizweb";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Connect to database
            String url = "jdbc:mysql://" + host + ":3306/" + dbName + "?useSSL=false&allowPublicKeyRetrieval=true";
            conn = DriverManager.getConnection(url, user, password);
            
            // Query to get quizzes for the domain
            String query = "SELECT QuizID, Title, DomainID FROM Quiz WHERE DomainID = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, domainId);
            
            rs = pstmt.executeQuery();
            
            StringBuilder json = new StringBuilder("[");
            boolean first = true;
            
            while(rs.next()) {
                if (!first) {
                    json.append(",");
                }
                json.append("{")
                    .append("\"id\":").append(rs.getInt("QuizID")).append(",")
                    .append("\"title\":\"").append(rs.getString("Title")).append("\",")
                    .append("\"domainId\":").append(rs.getInt("DomainID"))
                    .append("}");
                first = false;
            }
            json.append("]");
            
            out.print(json.toString());
            
        } catch (ClassNotFoundException e) {
            System.err.println("JDBC Driver not found: " + e.getMessage());
            out.print("{\"error\":\"Database driver not found\"}");
        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
            out.print("{\"error\":\"Database error: " + e.getMessage().replace("\"", "\\\"") + "\"}");
        } catch (Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
            out.print("{\"error\":\"Unexpected error: " + e.getMessage().replace("\"", "\\\"") + "\"}");
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }
} 