package main;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class QuestionUpdateServlet extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/plain; charset=UTF-8"); // Always return plain text
        PrintWriter out = response.getWriter();
        
        String action = request.getParameter("action");
        String questionId = request.getParameter("questionId");
        String quizId = request.getParameter("quizId");
        
        System.out.println("DEBUG: action = " + action + ", questionId = " + questionId + ", quizId = " + quizId);
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            // Database connection parameters
            String url = "jdbc:mysql://localhost:3306/quizweb?useSSL=false&allowPublicKeyRetrieval=true";
            String user = "root";
            String password = "dd@488124";
            
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Connect to database
            conn = DriverManager.getConnection(url, user, password);
            
            if ("update".equals(action)) {
                if (questionId == null || questionId.trim().isEmpty()) {
                    out.write("error: Missing questionId");
                    return;
                }
                // Update question
                String query = "UPDATE Question SET QuestionText = ?, Option1 = ?, Option2 = ?, Option3 = ?, Option4 = ?, CorrectOption = ? WHERE QuestionID = ?";
                pstmt = conn.prepareStatement(query);
                pstmt.setString(1, request.getParameter("questionText"));
                pstmt.setString(2, request.getParameter("option1"));
                pstmt.setString(3, request.getParameter("option2"));
                pstmt.setString(4, request.getParameter("option3"));
                pstmt.setString(5, request.getParameter("option4"));
                pstmt.setString(6, request.getParameter("correctOption"));
                pstmt.setString(7, questionId);
                
                int updated = pstmt.executeUpdate();
                if (updated > 0) {
                    out.write("success");
                } else {
                    out.write("error: No question updated");
                }
                
            } else if ("delete".equals(action)) {
                if (questionId == null || questionId.trim().isEmpty()) {
                    out.write("error: Missing questionId");
                    return;
                }
                // Delete question
                String query = "DELETE FROM Question WHERE QuestionID = ?";
                pstmt = conn.prepareStatement(query);
                pstmt.setString(1, questionId);
                
                int deleted = pstmt.executeUpdate();
                if (deleted > 0) {
                    out.write("success");
                } else {
                    out.write("error: No question deleted");
                }
            } else if ("add".equals(action)) {
                if (quizId == null || quizId.trim().isEmpty()) {
                    out.write("error: Missing quizId");
                    return;
                }
                // Insert new question
                String query = "INSERT INTO Question (QuizID, QuestionText, Option1, Option2, Option3, Option4, CorrectOption) VALUES (?, ?, ?, ?, ?, ?, ?)";
                pstmt = conn.prepareStatement(query);
                pstmt.setString(1, quizId);
                pstmt.setString(2, request.getParameter("questionText"));
                pstmt.setString(3, request.getParameter("option1"));
                pstmt.setString(4, request.getParameter("option2"));
                pstmt.setString(5, request.getParameter("option3"));
                pstmt.setString(6, request.getParameter("option4"));
                pstmt.setString(7, request.getParameter("correctOption"));
                int inserted = pstmt.executeUpdate();
                if (inserted > 0) {
                    out.write("success");
                } else {
                    out.write("error: No question added");
                }
            } else {
                out.write("error: Invalid action");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            out.write("error: " + e.getMessage());
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }
}