package main;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class AdminUsersServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String host = "localhost";
        String user = "root";
        String password = "dd@488124"; // Change this to your MySQL password
        String dbName = "quizweb";
        
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        
        try {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Connect to database
            conn = DriverManager.getConnection("jdbc:mysql://" + host + ":3306/" + dbName + "?useSSL=false&allowPublicKeyRetrieval=true", user, password);
            stmt = conn.createStatement();
            
            // Query to get all users
            String sql = "SELECT UserID, UserName, Email, Role FROM User";
            rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                out.println("<tr>");
                out.println("<td>" + rs.getString("UserName") + "</td>");
                out.println("<td>" + rs.getString("Email") + "</td>");
                out.println("<td>" + rs.getString("Role") + "</td>");
                out.println("<td class='action-buttons'>-</td>");
                out.println("</tr>");
            }
            
        } catch (Exception e) {
            out.println("<tr><td colspan='4'>Error: " + e.getMessage() + "</td></tr>");
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
} 