package main;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.Date;
import java.sql.SQLException;

@WebServlet("/AuthServlet")
public class AuthServlet extends HttpServlet {

    // Hardcoded Admin Credentials
    private static final String ADMIN_EMAIL = "admin@example.com";
    private static final String ADMIN_PASSWORD = "adminpass";

    // Database connection parameters (using the new password)
    private static final String DB_URL = "jdbc:mysql://localhost:3306/quizweb?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "dd@488124"; // Hardcoded password

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing action parameter");
            return;
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database driver not found");
            return;
        }

        switch (action) {
            case "signin":
                handleSignIn(request, response);
                break;
            case "signup":
                handleSignUp(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action");
        }
    }

    private void handleSignIn(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        if (email == null || password == null || email.trim().isEmpty() || password.trim().isEmpty()) {
            // Redirect back to auth.jsp with an error message
            request.setAttribute("error", "Email and password are required.");
            request.getRequestDispatcher("auth.jsp").forward(request, response);
            return;
        }

        // Check for admin login first
        if (ADMIN_EMAIL.equals(email) && ADMIN_PASSWORD.equals(password)) {
            HttpSession session = request.getSession();
            session.setAttribute("userId", -1); // Use a special ID for admin
            session.setAttribute("role", "Admin");
            session.setAttribute("username", "Admin");
            logLoginEvent(-1);
            response.sendRedirect("Admin.jsp"); // Redirect to admin panel
            return;
        }

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Authenticate user
            String sql = "SELECT UserID, UserName, Role FROM user WHERE Email = ? AND Password = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, email);
            pstmt.setString(2, password);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                int userId = rs.getInt("UserID");
                String username = rs.getString("UserName");
                String role = rs.getString("Role");

                HttpSession session = request.getSession();
                session.setAttribute("userId", userId);
                session.setAttribute("username", username);
                session.setAttribute("role", role);

                // Get specific role ID (TeacherID or StudentID)
                if ("Teacher".equals(role)) {
                    sql = "SELECT TeacherID FROM teacher WHERE UserID = ?";
                    pstmt = conn.prepareStatement(sql);
                    pstmt.setInt(1, userId);
                    ResultSet teacherRs = pstmt.executeQuery();
                    if (teacherRs.next()) {
                        session.setAttribute("teacherId", teacherRs.getInt("TeacherID"));
                    }
                    teacherRs.close();
                } else if ("Student".equals(role)) {
                    sql = "SELECT StudentID FROM student WHERE UserID = ?";
                    pstmt = conn.prepareStatement(sql);
                    pstmt.setInt(1, userId);
                    ResultSet studentRs = pstmt.executeQuery();
                    if (studentRs.next()) {
                        session.setAttribute("studentId", studentRs.getInt("StudentID"));
                    }
                    studentRs.close();
                }

                logLoginEvent(userId);

                // Redirect based on role
                if ("Teacher".equals(role)) {
                    response.sendRedirect("Teacher.jsp");
                } else if ("Student".equals(role)) {
                    response.sendRedirect("Student.jsp");
                } else {
                    // Should not happen if roles are only Teacher/Student/Admin
                    request.setAttribute("error", "Unknown user role.");
                    request.getRequestDispatcher("auth.jsp").forward(request, response);
                }
            } else {
                // Authentication failed
                request.setAttribute("error", "Invalid email or password.");
                request.getRequestDispatcher("auth.jsp").forward(request, response);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error during sign in: " + e.getMessage());
            request.getRequestDispatcher("auth.jsp").forward(request, response);
        } finally {
            try { if (rs != null) rs.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }

    private void handleSignUp(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String dobStr = request.getParameter("dob");

        if (username == null || email == null || password == null || dobStr == null ||
            username.trim().isEmpty() || email.trim().isEmpty() || password.trim().isEmpty() || dobStr.trim().isEmpty()) {
            // Redirect back to auth.jsp (sign-up part) with an error message
            request.setAttribute("error", "All fields are required for sign up.");
            request.getRequestDispatcher("auth.jsp").forward(request, response);
            return;
        }

        // Basic email format check (more robust validation needed in a real app)
         if (!email.contains("@")) {
             request.setAttribute("error", "Please enter a valid email address.");
             request.getRequestDispatcher("auth.jsp").forward(request, response);
             return;
         }

        Date dob = null;
        try {
            dob = Date.valueOf(dobStr);
        } catch (IllegalArgumentException e) {
            request.setAttribute("error", "Invalid date format for Date of Birth.");
             request.getRequestDispatcher("auth.jsp").forward(request, response);
            return;
        }

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Check if user already exists with this email
            String checkUserSql = "SELECT UserID FROM user WHERE Email = ?";
            pstmt = conn.prepareStatement(checkUserSql);
            pstmt.setString(1, email);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                // User already exists
                request.setAttribute("error", "User with this email already exists.");
                request.getRequestDispatcher("auth.jsp").forward(request, response);
                return;
            }
            rs.close();
            pstmt.close();

            // Insert into User table
            String userSql = "INSERT INTO user (UserName, Password, Email, DOB) VALUES (?, ?, ?, ?)";
            // Note: Role is intentionally left out here. It will be set after role selection.
            pstmt = conn.prepareStatement(userSql, Statement.RETURN_GENERATED_KEYS);
            pstmt.setString(1, username);
            pstmt.setString(2, password); // In a real app, hash the password!
            pstmt.setString(3, email);
            pstmt.setDate(4, dob);
            pstmt.executeUpdate();

            // Get generated UserID
            rs = pstmt.getGeneratedKeys();
            int userId = 0;
            if (rs.next()) {
                userId = rs.getInt(1);
            }

            if (userId > 0) {
                // Store userId in session for role selection
                HttpSession session = request.getSession();
                session.setAttribute("newUserId", userId);
                session.setAttribute("newUsername", username);
                session.setAttribute("newUserEmail", email);

                // Redirect to role selection page
                response.sendRedirect("roleSelection.jsp");
            } else {
                request.setAttribute("error", "Failed to create user.");
                 request.getRequestDispatcher("auth.jsp").forward(request, response);
            }

        } catch (SQLException e) {
            e.printStackTrace();
             request.setAttribute("error", "Database error during sign up: " + e.getMessage());
             request.getRequestDispatcher("auth.jsp").forward(request, response);
        } finally {
            try { if (rs != null) rs.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }

     private void logLoginEvent(int userId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            String sql = "INSERT INTO log_history (UserID, LoginTime) VALUES (?, NOW())";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, userId);
            pstmt.executeUpdate();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace(); // Log the error, but don't prevent login
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }
} 