package main;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/CreateQuizServlet")
public class CreateQuizServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/plain");
        HttpSession session = request.getSession();
        
        // DEBUG: Print all parameters
        System.out.println("--- CreateQuizServlet Parameter Dump ---");
        java.util.Enumeration<String> paramNames = request.getParameterNames();
        while (paramNames.hasMoreElements()) {
            String param = paramNames.nextElement();
            String[] values = request.getParameterValues(param);
            System.out.println(param + " = " + java.util.Arrays.toString(values));
        }
        System.out.println("----------------------------------------");
        
        // Check if teacher is logged in
        Integer teacherId = (Integer) session.getAttribute("teacherId");
        if (teacherId == null) {
            response.getWriter().write("error: Teacher not logged in");
            return;
        }
        
        // Get and validate domainId
        String domainIdStr = request.getParameter("domainId");
        if (domainIdStr == null || domainIdStr.trim().isEmpty()) {
            response.getWriter().write("error: Domain ID is required");
            return;
        }
        
        // Get and validate quiz title
        String quizTitle = request.getParameter("quizTitle");
        if (quizTitle == null || quizTitle.trim().isEmpty()) {
            response.getWriter().write("error: Quiz title is required");
            return;
        }
        
        Connection conn = null;
        try {
            // Database connection parameters
            String host = "localhost";
            String user = "root";
            String password = "dd@488124"; // Use your actual password
            String dbName = "quizweb";
            
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Connect to the database
            conn = DriverManager.getConnection(
                "jdbc:mysql://" + host + ":3306/" + dbName + "?useSSL=false&allowPublicKeyRetrieval=true",
                user,
                password
            );
            
            Integer domainId = Integer.parseInt(domainIdStr);
            
            // Insert quiz
            String quizQuery = "INSERT INTO quiz (Title, DomainID, TeacherID) VALUES (?, ?, ?)";
            PreparedStatement quizStmt = conn.prepareStatement(quizQuery, PreparedStatement.RETURN_GENERATED_KEYS);
            quizStmt.setString(1, quizTitle);
            quizStmt.setInt(2, domainId);
            quizStmt.setInt(3, teacherId);
            quizStmt.executeUpdate();
            
            // Get the generated quiz ID
            ResultSet rs = quizStmt.getGeneratedKeys();
            int quizId = 0;
            if (rs.next()) {
                quizId = rs.getInt(1);
            }
            
            // Get and validate questions data
            String[] questions = request.getParameterValues("questions[]");
            String[] optionsA = request.getParameterValues("optionsA[]");
            String[] optionsB = request.getParameterValues("optionsB[]");
            String[] optionsC = request.getParameterValues("optionsC[]");
            String[] optionsD = request.getParameterValues("optionsD[]");
            String[] correctOptions = request.getParameterValues("correctOptions[]");
            
            if (questions == null || questions.length == 0) {
                response.getWriter().write("error: At least one question is required");
                return;
            }
            
            // Insert questions
            String questionQuery = "INSERT INTO question (QuizID, QuestionText, Option1, Option2, Option3, Option4, CorrectOption) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement questionStmt = conn.prepareStatement(questionQuery);
            
            for (int i = 0; i < questions.length; i++) {
                if (questions[i] == null || questions[i].trim().isEmpty() ||
                    optionsA[i] == null || optionsA[i].trim().isEmpty() ||
                    optionsB[i] == null || optionsB[i].trim().isEmpty() ||
                    optionsC[i] == null || optionsC[i].trim().isEmpty() ||
                    optionsD[i] == null || optionsD[i].trim().isEmpty() ||
                    correctOptions[i] == null || correctOptions[i].trim().isEmpty()) {
                    response.getWriter().write("error: All question fields are required");
                    return;
                }
                
                questionStmt.setInt(1, quizId);
                questionStmt.setString(2, questions[i]);
                questionStmt.setString(3, optionsA[i]);
                questionStmt.setString(4, optionsB[i]);
                questionStmt.setString(5, optionsC[i]);
                questionStmt.setString(6, optionsD[i]);
                questionStmt.setString(7, correctOptions[i]);
                questionStmt.executeUpdate();
            }
            
            response.sendRedirect("quizsuccess.jsp");
            
        } catch (NumberFormatException e) {
            response.getWriter().write("error: Invalid domain ID format");
        } catch (Exception e) {
            response.getWriter().write("error: " + e.getMessage());
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception e) {
                    // Log error but don't throw it
                    System.err.println("Error closing connection: " + e.getMessage());
                }
            }
        }
    }
} 