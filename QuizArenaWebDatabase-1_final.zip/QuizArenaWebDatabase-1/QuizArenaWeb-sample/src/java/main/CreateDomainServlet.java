package main;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class CreateDomainServlet extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();
        
        String domainName = request.getParameter("domainName");
        
        if (domainName == null || domainName.trim().isEmpty()) {
            out.print("Domain name cannot be empty");
            return;
        }
        
        String host = "localhost";
        String user = "root";
        String password = "dd@488124";
        String dbName = "quizweb";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://" + host + ":3306/" + dbName + "?useSSL=false&allowPublicKeyRetrieval=true", user, password);
            
            // Insert new domain with QuizCount set to 0
            String query = "INSERT INTO Domain (DomainName, QuizCount) VALUES (?, 0)";
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, domainName);
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                out.print("success");
            } else {
                out.print("Failed to create domain");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            out.print("Error: " + e.getMessage());
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }
} 