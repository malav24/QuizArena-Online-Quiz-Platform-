package main;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class QuizResultServlet extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String quizId = request.getParameter("quizId");
        String score = request.getParameter("score");
        HttpSession session = request.getSession();
        Object studentIdObj = session.getAttribute("studentId");
        
        // Add debug logging
        System.out.println("Quiz ID: " + quizId);
        System.out.println("Score: " + score);
        System.out.println("Student ID from session: " + studentIdObj);
        
        // Validate all required parameters
        if (quizId == null || score == null) {
            System.out.println("Missing quizId or score parameters");
            response.sendRedirect("QuizResult.jsp");
            return;
        }

        if (studentIdObj == null) {
            System.out.println("No student ID found in session");
            response.sendRedirect("Student.jsp"); // Redirect to login if no student ID
            return;
        }

        try {
            int studentId = (studentIdObj instanceof Integer) ? (Integer)studentIdObj : Integer.parseInt(studentIdObj.toString());
            int quizIdInt = Integer.parseInt(quizId);
            int scoreInt = Integer.parseInt(score);

            String url = "jdbc:mysql://localhost:3306/quizweb?useSSL=false&allowPublicKeyRetrieval=true";
            String user = "root";
            String password = "dd@488124";

            try (Connection conn = DriverManager.getConnection(url, user, password)) {
                // First get total number of questions for this quiz
                String countSql = "SELECT COUNT(*) as total FROM Question WHERE QuizID = ?";
                int totalQuestions = 0;
                try (PreparedStatement countStmt = conn.prepareStatement(countSql)) {
                    countStmt.setInt(1, quizIdInt);
                    ResultSet rs = countStmt.executeQuery();
                    if (rs.next()) {
                        totalQuestions = rs.getInt("total");
                    }
                }

                if (totalQuestions == 0) {
                    System.out.println("No questions found for quiz ID: " + quizIdInt);
                    response.sendRedirect("QuizResult.jsp");
                    return;
                }

                // Then insert the result
                String sql = "INSERT INTO result (StudentID, QuizID, Score, AttemptDate) VALUES (?, ?, ?, CURDATE())";
                try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setInt(1, studentId);
                    pstmt.setInt(2, quizIdInt);
                    pstmt.setInt(3, scoreInt);
                    int rowsAffected = pstmt.executeUpdate();
                    System.out.println("Rows affected by insert: " + rowsAffected);
                }

                // Redirect to result page with both score and total
                response.sendRedirect("QuizResult.jsp?score=" + score + "&total=" + totalQuestions);
            }
        } catch (NumberFormatException e) {
            System.out.println("Number format exception: " + e.getMessage());
            response.sendRedirect("QuizResult.jsp");
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
            e.printStackTrace();
            response.sendRedirect("QuizResult.jsp");
        } catch (Exception e) {
            System.out.println("Unexpected error: " + e.getMessage());
            e.printStackTrace();
            response.sendRedirect("QuizResult.jsp");
        }
    }
}