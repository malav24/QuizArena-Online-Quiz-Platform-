package main;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class AdminQuizzesServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String host = "localhost";
        String user = "root";
        String password = "dd@488124"; // Change as needed
        String dbName = "quizweb";

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://" + host + ":3306/" + dbName + "?useSSL=false&allowPublicKeyRetrieval=true", user, password);
            stmt = conn.createStatement();
            // Join Quiz, Teacher, and User to get quiz title and creator name
            String sql = "SELECT q.QuizID, q.Title, u.UserName AS CreatorName FROM Quiz q JOIN Teacher t ON q.TeacherID = t.TeacherID JOIN User u ON t.UserID = u.UserID ORDER BY q.QuizID";
            rs = stmt.executeQuery(sql);
            int count = 1;
            while (rs.next()) {
                out.println("<tr>");
                out.println("<td>" + (count++) + "</td>");
                out.println("<td>" + rs.getString("Title") + "</td>");
                out.println("<td>" + rs.getString("CreatorName") + "</td>");
                out.println("<td class='action-buttons'>-</td>");
                out.println("</tr>");
            }
        } catch (Exception e) {
            out.println("<tr><td colspan='4'>Error: " + e.getMessage() + "</td></tr>");
        } finally {
            try { if (rs != null) rs.close(); } catch (SQLException e) {}
            try { if (stmt != null) stmt.close(); } catch (SQLException e) {}
            try { if (conn != null) conn.close(); } catch (SQLException e) {}
        }
    }
} 