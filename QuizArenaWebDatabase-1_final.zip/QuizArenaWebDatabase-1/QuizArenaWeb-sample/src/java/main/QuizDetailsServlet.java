package main;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.*;

public class QuizDetailsServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String quizId = request.getParameter("quizId");
        if (quizId == null || quizId.trim().isEmpty()) {
            request.setAttribute("error", "Quiz ID is required");
            request.getRequestDispatcher("QuizDetails.jsp").forward(request, response);
            return;
        }
        
        String host = "localhost";
        String user = "root";
        String password = "dd@488124";
        String dbName = "quizweb";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        System.out.println("QuizDetailsServlet: START, quizId=" + quizId);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://" + host + ":3306/" + dbName + "?useSSL=false&allowPublicKeyRetrieval=true", user, password);
            System.out.println("QuizDetailsServlet: Connected to DB, running query for quizId=" + quizId);
            
            // Query to get quiz details and questions (LEFT JOIN to always get quiz info)
            String query = "SELECT q.QuizID, q.Title, d.DomainName, " +
                          "qu.QuestionID, qu.QuestionText, qu.Option1, qu.Option2, qu.Option3, qu.Option4, qu.CorrectOption " +
                          "FROM Quiz q " +
                          "JOIN Domain d ON q.DomainID = d.DomainID " +
                          "LEFT JOIN Question qu ON q.QuizID = qu.QuizID " +
                          "WHERE q.QuizID = ?";
            
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, quizId);
            
            rs = pstmt.executeQuery();
            
            String quizTitle = null;
            String domainName = null;
            List<Map<String, Object>> questions = new ArrayList<>();
            
            boolean foundQuiz = false;
            while (rs.next()) {
                if (quizTitle == null) {
                    quizTitle = rs.getString("Title");
                    domainName = rs.getString("DomainName");
                }
                foundQuiz = true;
                // Debug: print all columns for each row
                System.out.println("ROW: QuizID=" + rs.getObject("QuizID") + ", QuestionID=" + rs.getObject("QuestionID") + ", QuestionText=" + rs.getObject("QuestionText") + ", Option1=" + rs.getObject("Option1") + ", Option2=" + rs.getObject("Option2") + ", Option3=" + rs.getObject("Option3") + ", Option4=" + rs.getObject("Option4") + ", CorrectOption=" + rs.getObject("CorrectOption"));
                if (rs.getObject("QuestionID") != null) {
                    Map<String, Object> question = new HashMap<>();
                    question.put("id", rs.getInt("QuestionID"));
                    question.put("text", rs.getString("QuestionText"));
                    question.put("a", rs.getString("Option1"));
                    question.put("b", rs.getString("Option2"));
                    question.put("c", rs.getString("Option3"));
                    question.put("d", rs.getString("Option4"));
                    question.put("correct", rs.getString("CorrectOption"));
                    questions.add(question);
                }
            }
            
            if (!foundQuiz) {
                System.out.println("NO ROWS FETCHED for quizId=" + quizId);
            }
            
            // Debug output
            System.out.println("QuizDetailsServlet: quizId=" + quizId + ", quizTitle=" + quizTitle + ", domainName=" + domainName + ", questions.size=" + questions.size());
            
            if (!foundQuiz) {
                request.setAttribute("error", "Quiz not found for the given ID.");
            }
            request.setAttribute("quizTitle", quizTitle);
            request.setAttribute("domainName", domainName);
            request.setAttribute("questions", questions);
            request.getRequestDispatcher("QuizDetails.jsp").forward(request, response);
        } catch (Exception e) {
            request.setAttribute("error", e.getMessage());
            request.getRequestDispatcher("QuizDetails.jsp").forward(request, response);
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }
} 