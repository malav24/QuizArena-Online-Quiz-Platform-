package main;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentQuizServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String domainId = request.getParameter("domainId");
        
        if (domainId == null || domainId.trim().isEmpty()) {
            out.println("No domain selected");
            return;
        }

        try {
            // Database connection parameters
            String url = "jdbc:mysql://localhost:3306/quizweb?useSSL=false&allowPublicKeyRetrieval=true";
            String user = "root";
            String password = "dd@488124"; // Add your database password here

            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to database
            Connection conn = DriverManager.getConnection(url, user, password);
            
            // Prepare SQL query
            String sql = "SELECT QuizID, Title FROM Quiz WHERE DomainID = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, domainId);
            
            // Execute query
            ResultSet rs = pstmt.executeQuery();
            
            // Build HTML response
            StringBuilder html = new StringBuilder();
            
            while (rs.next()) {
                int quizId = rs.getInt("QuizID");
                String title = rs.getString("Title");
                
                // Create card HTML
                html.append("<a href='QuizTestServlet?quizId=").append(quizId).append("' class='card-link'>");
                html.append("<div class='card'>");
                html.append("<h2><br><br>").append(title).append("<br><br></h2>");
                html.append("</div>");
                html.append("</a>");
            }
            
            // Send response
            out.println(html.toString());
            
            // Close resources
            rs.close();
            pstmt.close();
            conn.close();
            
        } catch (Exception e) {
            out.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
} 