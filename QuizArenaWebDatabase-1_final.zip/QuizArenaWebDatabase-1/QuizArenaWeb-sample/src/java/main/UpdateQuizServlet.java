package main;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UpdateQuizServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String quizId = request.getParameter("quizId");
        
        if (quizId == null || quizId.trim().isEmpty()) {
            response.sendRedirect("Teacher.jsp");
            return;
        }

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            // Database connection parameters
            String url = "jdbc:mysql://localhost:3306/quizweb?useSSL=false&allowPublicKeyRetrieval=true";
            String user = "root";
            String password = "dd@488124";
            
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Connect to database
            conn = DriverManager.getConnection(url, user, password);
            
            // Query to get quiz details and questions
            String query = "SELECT q.QuizID, q.Title, d.DomainName, " +
                          "qu.QuestionID, qu.QuestionText, qu.Option1, qu.Option2, qu.Option3, qu.Option4, qu.CorrectOption " +
                          "FROM Quiz q " +
                          "JOIN Domain d ON q.DomainID = d.DomainID " +
                          "LEFT JOIN Question qu ON q.QuizID = qu.QuizID " +
                          "WHERE q.QuizID = ?";
            
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, quizId);
            
            rs = pstmt.executeQuery();
            
            String quizTitle = null;
            String domainName = null;
            List<Question> questions = new ArrayList<>();
            
            while (rs.next()) {
                if (quizTitle == null) {
                    quizTitle = rs.getString("Title");
                    domainName = rs.getString("DomainName");
                }
                
                if (rs.getInt("QuestionID") != 0) {
                    Question question = new Question();
                    question.setId(rs.getInt("QuestionID"));
                    question.setText(rs.getString("QuestionText"));
                    question.setOption1(rs.getString("Option1"));
                    question.setOption2(rs.getString("Option2"));
                    question.setOption3(rs.getString("Option3"));
                    question.setOption4(rs.getString("Option4"));
                    question.setCorrectOption(rs.getString("CorrectOption"));
                    questions.add(question);
                }
            }
            
            request.setAttribute("quizId", quizId);
            request.setAttribute("quizTitle", quizTitle);
            request.setAttribute("domainName", domainName);
            request.setAttribute("questions", questions);
            request.getRequestDispatcher("UpdateQuiz.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error loading quiz: " + e.getMessage());
            request.getRequestDispatcher("Teacher.jsp").forward(request, response);
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("questionId received: " + request.getParameter("questionId"));
        // Implementation of doPost method
    }
}