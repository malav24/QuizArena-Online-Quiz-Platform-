/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class DomainServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        String host = "localhost";
        String user = "root";
        String password = "dd@488124"; // Change this to your MySQL password
        String dbName = "quizweb";
        
        Connection conn = null;
        Statement stmt = null;
        
        try {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Connect to database
            conn = DriverManager.getConnection("jdbc:mysql://" + host + ":3306/" + dbName + "?useSSL=false&allowPublicKeyRetrieval=true", user, password);
            stmt = conn.createStatement();
            
            // Query to get all domains
            String query = "SELECT DomainID, DomainName, QuizCount FROM Domain";
            ResultSet rs = stmt.executeQuery(query);
            
            StringBuilder json = new StringBuilder("[");
            boolean first = true;
            
            while(rs.next()) {
                if (!first) {
                    json.append(",");
                }
                json.append("{")
                    .append("\"id\":").append(rs.getInt("DomainID")).append(",")
                    .append("\"name\":\"").append(rs.getString("DomainName")).append("\",")
                    .append("\"quizCount\":").append(rs.getInt("QuizCount"))
                    .append("}");
                first = false;
            }
            json.append("]");
            
            out.print(json.toString());
            
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"error\":\"" + e.getMessage().replace("\"", "\\\"") + "\"}");
        } finally {
            try { if (stmt != null) stmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();

        String action = request.getParameter("action");
        String domainIdStr = request.getParameter("domainId");

        if (action == null) {
            out.print("Error: Missing action parameter");
            return;
        }

        int domainId = -1;
        if (domainIdStr != null && !domainIdStr.isEmpty()) {
            try {
                domainId = Integer.parseInt(domainIdStr);
            } catch (NumberFormatException e) {
                out.print("Error: Invalid Domain ID");
                return;
            }
        }

        String host = "localhost";
        String user = "root";
        String password = "dd@488124";
        String dbName = "quizweb";

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://" + host + ":3306/" + dbName + "?useSSL=false&allowPublicKeyRetrieval=true", user, password);

            if ("update".equals(action)) {
                String domainName = request.getParameter("domainName");
                if (domainId == -1 || domainName == null || domainName.trim().isEmpty()) {
                    out.print("Error: Missing Domain ID or Domain Name");
                    return;
                }
                String sql = "UPDATE Domain SET DomainName = ? WHERE DomainID = ?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, domainName);
                pstmt.setInt(2, domainId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    out.print("success");
                } else {
                    out.print("Error: Domain not found or no changes made");
                }
            } else if ("delete".equals(action)) {
                if (domainId == -1) {
                     out.print("Error: Missing Domain ID");
                     return;
                }

                // Start transaction (optional but good practice)
                conn.setAutoCommit(false);

                // 1. Get all QuizIDs associated with the DomainID
                String getQuizIdsSql = "SELECT QuizID FROM Quiz WHERE DomainID = ?";
                PreparedStatement pstmtGetQuizIds = conn.prepareStatement(getQuizIdsSql);
                pstmtGetQuizIds.setInt(1, domainId);
                ResultSet rsQuizIds = pstmtGetQuizIds.executeQuery();

                // 2. Delete questions associated with each quiz in the domain
                String deleteQuestionsSql = "DELETE FROM Question WHERE QuizID = ?";
                PreparedStatement pstmtDeleteQuestions = conn.prepareStatement(deleteQuestionsSql);

                while (rsQuizIds.next()) {
                    int quizId = rsQuizIds.getInt("QuizID");
                    pstmtDeleteQuestions.setInt(1, quizId);
                    pstmtDeleteQuestions.executeUpdate();
                }
                pstmtDeleteQuestions.close();
                rsQuizIds.close();
                pstmtGetQuizIds.close();

                // 3. Delete quizzes associated with the domain
                String deleteQuizzesSql = "DELETE FROM Quiz WHERE DomainID = ?";
                PreparedStatement pstmtDeleteQuizzes = conn.prepareStatement(deleteQuizzesSql);
                pstmtDeleteQuizzes.setInt(1, domainId);
                pstmtDeleteQuizzes.executeUpdate();
                pstmtDeleteQuizzes.close();

                // 4. Delete the domain
                String deleteDomainSql = "DELETE FROM Domain WHERE DomainID = ?";
                PreparedStatement pstmtDeleteDomain = conn.prepareStatement(deleteDomainSql);
                pstmtDeleteDomain.setInt(1, domainId);
                int rowsAffected = pstmtDeleteDomain.executeUpdate();
                pstmtDeleteDomain.close();

                if (rowsAffected > 0) {
                    conn.commit(); // Commit the transaction if successful
                    out.print("success");
                } else {
                    conn.rollback(); // Rollback if domain not found
                    out.print("Error: Domain not found");
                }

            } else {
                out.print("Error: Invalid action");
            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            out.print("Error: Database driver not found");
        } catch (SQLException e) {
            e.printStackTrace();
            out.print("Error: Database error - " + e.getMessage());
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }
}
