package main;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.SQLException;

@WebServlet("/RoleSelectionServlet")
public class RoleSelectionServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/quizweb?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "dd@488124"; // Hardcoded password

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("newUserId");
        String username = (String) session.getAttribute("newUsername");
        String email = (String) session.getAttribute("newUserEmail");
        String role = request.getParameter("role");

        // Check if user ID and role are valid
        if (userId == null || username == null || email == null || role == null || (!role.equals("Teacher") && !role.equals("Student"))) {
            // Invalid state, redirect to auth page
            session.removeAttribute("newUserId");
            session.removeAttribute("newUsername");
            session.removeAttribute("newUserEmail");
            response.sendRedirect("auth.jsp?error=Invalid role selection");
            return;
        }

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            conn.setAutoCommit(false); // Start transaction

            // 1. Update user table with the selected role
            String updateUserSql = "UPDATE user SET Role = ? WHERE UserID = ?";
            pstmt = conn.prepareStatement(updateUserSql);
            pstmt.setString(1, role);
            pstmt.setInt(2, userId);
            pstmt.executeUpdate();
            pstmt.close();

            // 2. Insert into the appropriate role table (Teacher or Student)
            int roleId = 0; // To store TeacherID or StudentID
            if ("Teacher".equals(role)) {
                String insertTeacherSql = "INSERT INTO teacher (Name, UserID) VALUES (?, ?)";
                pstmt = conn.prepareStatement(insertTeacherSql, Statement.RETURN_GENERATED_KEYS);
                pstmt.setString(1, username);
                pstmt.setInt(2, userId);
                pstmt.executeUpdate();

                rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    roleId = rs.getInt(1);
                }
                rs.close();
                session.setAttribute("teacherId", roleId);

            } else if ("Student".equals(role)) {
                String insertStudentSql = "INSERT INTO student (Name, UserID) VALUES (?, ?)";
                pstmt = conn.prepareStatement(insertStudentSql, Statement.RETURN_GENERATED_KEYS);
                pstmt.setString(1, username);
                pstmt.setInt(2, userId);
                pstmt.executeUpdate();

                rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    roleId = rs.getInt(1);
                }
                rs.close();
                 session.setAttribute("studentId", roleId);
            }
            pstmt.close();

            conn.commit(); // Commit transaction

            // Remove temporary session attributes set during sign-up
            session.removeAttribute("newUserId");
            session.removeAttribute("newUsername");
            session.removeAttribute("newUserEmail");

            // Set permanent session attributes for the logged-in user
            session.setAttribute("userId", userId);
            session.setAttribute("username", username);
            session.setAttribute("role", role);

            // Log the login event
             logLoginEvent(userId);

            // Redirect to the appropriate dashboard
            if ("Teacher".equals(role)) {
                response.sendRedirect("Teacher.jsp");
            } else if ("Student".equals(role)) {
                response.sendRedirect("Student.jsp");
            }

        } catch (SQLException e) {
            try { if (conn != null) conn.rollback(); } catch (SQLException rollbackEx) { rollbackEx.printStackTrace(); }
            e.printStackTrace();
            // Redirect back to role selection or auth page with error
            request.setAttribute("error", "Database error during role selection: " + e.getMessage());
            request.getRequestDispatcher("roleSelection.jsp").forward(request, response);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
             request.setAttribute("error", "Database driver not found.");
             request.getRequestDispatcher("roleSelection.jsp").forward(request, response);
        } finally {
            try { if (rs != null) rs.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }

     // Replicate the logLoginEvent method from AuthServlet
     private void logLoginEvent(int userId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            String sql = "INSERT INTO log_history (UserID, LoginTime) VALUES (?, NOW())";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, userId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Log the error, but don't fail the login process
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }
} 