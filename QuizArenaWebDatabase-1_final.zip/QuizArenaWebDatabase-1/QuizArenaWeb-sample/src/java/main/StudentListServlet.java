/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/StudentListServlet")
public class StudentListServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String url = "jdbc:mysql://localhost:3306/quizweb?useSSL=false&allowPublicKeyRetrieval=true";
        String user = "root";
        String password = "dd@488124";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url, user, password);

            String sql = "SELECT s.StudentID, s.Name, u.Email, " +
                         "COUNT(r.AttemptID) AS QuizzesTaken, " +
                         "IFNULL(AVG(r.Score), 0) AS AvgScore " +
                         "FROM student s " +
                         "JOIN user u ON s.UserID = u.UserID " +
                         "LEFT JOIN result r ON s.StudentID = r.StudentID " +
                         "GROUP BY s.StudentID, s.Name, u.Email " +
                         "ORDER BY s.StudentID ASC";

            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();

            out.println("<div class='student-cards'>");
            while (rs.next()) {
                out.println("<div class='student-card'>");
                out.println("<div class='student-info'>");
                out.println("<div class='student-id'>" + String.format("STU%03d", rs.getInt("StudentID")) + "</div>");
                out.println("<div class='student-name'>" + rs.getString("Name") + "</div>");
                out.println("<div class='student-email'>" + rs.getString("Email") + "</div>");
                out.println("</div>");
                out.println("<div class='student-meta'>");
                out.println("<div class='student-quizzes'><b>Quizzes Taken:</b> " + rs.getInt("QuizzesTaken") + "</div>");
                out.println("<div class='student-score'><b>Average Score:</b> " + String.format("%.0f%%", rs.getDouble("AvgScore")) + "</div>");
                out.println("</div>");
                out.println("<div class='student-actions'>");
                out.println("<button class='view-btn' onclick=\"window.location.href='StudentProfile.jsp?studentId=" + rs.getInt("StudentID") + "'\"><i class='fas fa-eye'></i> View</button>");
                out.println("<button class='msg-btn'><i class='fas fa-envelope'></i> Message</button>");
                out.println("</div>");
                out.println("</div>");
            }
            out.println("</div>");

            rs.close();
            pstmt.close();
            conn.close();
        } catch (Exception e) {
            out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
        }
    }
}
